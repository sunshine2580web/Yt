# Dinosaur extinction — Remotion project (1080×1920, 30fps, 66.9s)
```bash
npm install
npm run studio        # preview
npm run render        # → out/dino.mp4
```
Captions come from `public/captions.srt` (`npm run captions` regenerates `src/captions.ts`).
For the voice-over: put it at `public/voice.mp3` and set `HAS_VO = true` in `src/Dino.tsx`.
Needs internet on first render (Noto Sans Bengali loads via @remotion/google-fonts).
