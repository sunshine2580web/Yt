import React from "react";
import { AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { fontFamily } from "./fonts";
import { Entrance, SceneWrap, useCount } from "./Layers";
import { bn, ms2f, SCENES, theme } from "./theme";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const CX = 540;
const PY = 760; // planet centre y (keeps art above the caption zone, ~y>1150)
const R = 320;

const Planet: React.FC<{ shake?: number; dim?: number }> = ({ shake = 0, dim = 1 }) => {
  const frame = useCurrentFrame();
  const breathe = 1 + Math.sin(frame / 22) * 0.012;
  return (
    <div style={{ position: "absolute", left: CX - R, top: PY - R, width: R * 2, height: R * 2, borderRadius: "50%",
      transform: `translate(${Math.sin(frame * 2.3) * shake}px, ${Math.cos(frame * 3.1) * shake}px) scale(${breathe})`,
      background: `radial-gradient(circle at 32% 28%, #6B5440 0%, #2A1B12 55%, ${theme.colors.bgAlt} 100%)`,
      boxShadow: `inset -30px -30px 90px rgba(0,0,0,0.75), inset 8px 8px 30px ${theme.colors.accent}33, 0 0 80px ${theme.colors.accent}14`,
      filter: `brightness(${dim})` }} />
  );
};

const Label: React.FC<{ children: React.ReactNode; size?: number; color?: string }> = ({ children, size = 52, color = theme.colors.textDim }) => (
  <div style={{ fontFamily, fontWeight: 700, fontSize: size, color, textAlign: "center", lineHeight: 1.4 }}>{children}</div>
);

// ───────────── Scene 1: the age of dinosaurs (0–12s) ─────────────
export const EraScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const n = useCount(66, 6);
  const ticks = 24;
  return (
    <SceneWrap>
      <Planet />
      {Array.from({ length: ticks }).map((_, i) => {
        const p = spring({ frame: frame - 10 - i * 3, fps, config: theme.spring.snappy });
        const a = (360 / ticks) * i + frame * 0.15;
        return (
          <div key={i} style={{ position: "absolute", left: CX - 2, top: PY - 2, width: 4, height: 22 * p, borderRadius: 4,
            background: theme.colors.accent, opacity: 0.5 * p, transformOrigin: "50% 0%",
            transform: `rotate(${a}deg) translateY(${R + 40}px)` }} />
        );
      })}
      <div style={{ position: "absolute", top: 190, width: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
        <Entrance delay={4}>
          <div style={{ fontFamily, fontWeight: 800, fontSize: 210, lineHeight: 1.1, color: theme.colors.primary,
            textShadow: `0 0 60px ${theme.colors.glow}`, fontVariantNumeric: "tabular-nums" }}>{bn(n)}</div>
        </Entrance>
        <Entrance delay={14}><Label>মিলিয়ন বছর আগে</Label></Entrance>
      </div>
    </SceneWrap>
  );
};

// ───────────── Scene 2: the asteroid (12–30.3s) ─────────────
const IMPACT = ms2f(22980) - ms2f(SCENES.impact[0]); // local frame of "সংঘর্ষে"
const HIT = { x: CX + 235, y: PY - 215 };

export const ImpactScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = interpolate(frame, [20, IMPACT], [0, 1], { easing: theme.ease.in, ...clamp });
  const start = { x: 1250, y: -200 };
  const ax = interpolate(t, [0, 1], [start.x, HIT.x]);
  const ay = interpolate(t, [0, 1], [start.y, HIT.y]);
  const size = interpolate(t, [0, 1], [50, 150]);
  const ang = (Math.atan2(HIT.y - start.y, HIT.x - start.x) * 180) / Math.PI;
  const before = frame < IMPACT;
  const after = frame - IMPACT;
  const flash = interpolate(after, [0, 3, 22], [0, 0.85, 0], { easing: theme.ease.out, ...clamp });
  const shake = interpolate(after, [0, 40], [22, 0], { easing: theme.ease.out, ...clamp });
  return (
    <SceneWrap>
      <Planet shake={after >= 0 ? shake : 0} />
      {/* size chip: ~10 km */}
      <div style={{ position: "absolute", top: 200, width: "100%", display: "flex", justifyContent: "center" }}>
        <Entrance delay={6}>
          <div style={{ fontFamily, fontWeight: 800, fontSize: 96, color: theme.colors.text, lineHeight: 1.3 }}>
            {bn(10)} <span style={{ fontSize: 56, color: theme.colors.textDim }}>কিলোমিটার চওড়া</span>
          </div>
        </Entrance>
      </div>
      {/* asteroid + trail */}
      {before && (
        <>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} style={{ position: "absolute", left: ax - 300 - i * 6, top: ay - (size * 0.4) / 2 - i,
              width: 300 + i * 90, height: size * (0.4 - i * 0.03), borderRadius: size, filter: "blur(14px)",
              background: `linear-gradient(90deg, transparent, ${theme.colors.primary}${(55 - i * 5).toString(16).padStart(2, "0")})`,
              transformOrigin: "100% 50%", transform: `translateX(300px) rotate(${ang}deg) translateX(-300px)`, opacity: 0.8 }} />
          ))}
          <div style={{ position: "absolute", left: ax - size / 2, top: ay - size / 2, width: size, height: size, borderRadius: "46% 54% 50% 50%",
            background: `radial-gradient(circle at 35% 30%, ${theme.colors.accent}, ${theme.colors.primary} 55%, #3A1405)`,
            boxShadow: `0 0 ${size}px ${theme.colors.glow}`, transform: `rotate(${frame * 6}deg)` }} />
        </>
      )}
      {/* impact: shockwaves, debris, crater */}
      {after >= 0 && (
        <>
          <div style={{ position: "absolute", left: HIT.x - 40, top: HIT.y - 22, width: 80, height: 44, borderRadius: "50%",
            background: "#0A0503", boxShadow: `0 0 40px ${theme.colors.primary}88` }} />
          {[0, 1, 2, 3].map((i) => {
            const p = interpolate(after - i * 5, [0, 70], [0, 1], { easing: theme.ease.out, ...clamp });
            const d = 120 + p * 900;
            return <div key={i} style={{ position: "absolute", left: HIT.x - d / 2, top: HIT.y - d / 2, width: d, height: d, borderRadius: "50%",
              border: `${6 - i}px solid ${theme.colors.primary}`, opacity: (1 - p) * (after - i * 5 > 0 ? 1 : 0) }} />;
          })}
          {Array.from({ length: 28 }).map((_, i) => {
            const a = random(`a${i}`) * Math.PI * 2;
            const v = 180 + random(`v${i}`) * 520;
            const p = interpolate(after, [0, 90], [0, 1], { easing: theme.ease.out, ...clamp });
            return <div key={i} style={{ position: "absolute", left: HIT.x + Math.cos(a) * v * p, top: HIT.y + Math.sin(a) * v * p + p * p * 160,
              width: 10 + random(`s${i}`) * 14, height: 10 + random(`s${i}`) * 14, borderRadius: 4, background: theme.colors.accent,
              opacity: (1 - p) * 0.9, transform: `rotate(${i * 40 + after * 8}deg)` }} />;
          })}
        </>
      )}
      <AbsoluteFill style={{ background: `radial-gradient(circle at ${HIT.x}px ${HIT.y}px, #fff3e0, ${theme.colors.primary} 40%, transparent 75%)`, opacity: flash }} />
    </SceneWrap>
  );
};

// ───────────── Scene 3: dust & the long winter (30.3–51.2s) ─────────────
const COUNT_AT = ms2f(45840) - ms2f(SCENES.winter[0]); // "পঁচাত্তর শতাংশ"

export const WinterScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const dust = interpolate(frame, [0, 360], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const sunO = interpolate(frame, [0, 380], [1, 0], { easing: theme.ease.inOut, ...clamp });
  const temp = interpolate(frame, [200, 430], [1, 0.22], { easing: theme.ease.inOut, ...clamp });
  const barO = interpolate(frame, [COUNT_AT - 30, COUNT_AT - 12], [1, 0], { easing: theme.ease.in, ...clamp });
  const n = useCount(75, COUNT_AT);
  return (
    <SceneWrap>
      {/* sun — hero until it is swallowed by dust */}
      <div style={{ position: "absolute", left: CX - 170, top: PY - 170 + Math.sin(frame / 30) * 6, width: 340, height: 340, borderRadius: "50%",
        background: `radial-gradient(circle, #FFE2C2, ${theme.colors.primary} 60%, transparent 72%)`, opacity: sunO,
        boxShadow: `0 0 160px ${theme.colors.glow}` }} />
      {/* drifting dust clouds, thickening over time */}
      {Array.from({ length: 16 }).map((_, i) => {
        const x = random(`dx${i}`) * 1300 - 110 + Math.sin(frame / (60 + i * 7) + i) * 40;
        const y = 80 + random(`dy${i}`) * 900;
        const enter = spring({ frame: frame - i * 14, fps, config: theme.spring.smooth });
        const s = 420 + random(`ds${i}`) * 420;
        return <div key={i} style={{ position: "absolute", left: x - s / 2, top: y - s / 2 - (1 - enter) * 300, width: s, height: s, borderRadius: "50%",
          filter: "blur(70px)", background: theme.colors.dust, opacity: enter * (0.35 + dust * 0.6) }} />;
      })}
      <AbsoluteFill style={{ background: `rgba(8,5,3,${dust * 0.55})` }} />
      {/* temperature bar */}
      <div style={{ position: "absolute", top: 930, left: 0, width: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: 16, opacity: barO }}>
        <Entrance delay={150}>
          <Label size={44}>তাপমাত্রা</Label>
          <div style={{ marginTop: 14, width: 560, height: 16, borderRadius: 16, background: "rgba(244,233,218,0.14)", overflow: "hidden" }}>
            <div style={{ width: `${temp * 100}%`, height: "100%", borderRadius: 16, background: theme.colors.accent }} />
          </div>
        </Entrance>
      </div>
      {/* 75% extinction counter */}
      {frame >= COUNT_AT - 2 && (
        <div style={{ position: "absolute", top: 380, width: "100%", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <Entrance delay={COUNT_AT}>
            <div style={{ fontFamily, fontWeight: 800, fontSize: 300, lineHeight: 1.15, color: theme.colors.primary,
              textShadow: `0 0 70px ${theme.colors.glow}`, fontVariantNumeric: "tabular-nums" }}>{bn(n)}%</div>
          </Entrance>
          <Entrance delay={COUNT_AT + 10}><Label size={56}>প্রজাতি বিলুপ্ত</Label></Entrance>
        </div>
      )}
    </SceneWrap>
  );
};

// ───────────── Scene 4: the birds (51.2–67s) ─────────────
const Bird: React.FC<{ scale: number }> = ({ scale }) => {
  const frame = useCurrentFrame();
  const flap = Math.sin(frame / 5);
  const wing = (dir: 1 | -1) => (
    <g style={{ transformOrigin: "0px 0px", transform: `scaleX(${dir}) rotate(${-flap * 22}deg)` }}>
      <path d="M0 0 C60 -70 150 -80 230 -30 C160 -30 90 -10 0 28 Z" fill={theme.colors.accent} />
    </g>
  );
  return (
    <svg width={520 * scale} height={300 * scale} viewBox="-260 -150 520 300" style={{ overflow: "visible" }}>
      {wing(1)}{wing(-1)}
      <ellipse cx="0" cy="12" rx="34" ry="50" fill={theme.colors.accent} />
      <circle cx="0" cy="-40" r="20" fill={theme.colors.accent} />
      <path d="M-4 -44 L-40 -36 L-4 -30 Z" fill={theme.colors.accent} />
      <path d="M-18 58 L0 120 L18 58 Z" fill={theme.colors.accent} />
    </svg>
  );
};

export const BirdScene: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const rise = spring({ frame: frame - 4, fps, config: theme.spring.smooth });
  const x = interpolate(frame, [0, 120, 470], [-260, 0, 40], { easing: theme.ease.out, ...clamp });
  return (
    <SceneWrap>
      {/* dawn returning: the hero sun rises behind the bird */}
      <div style={{ position: "absolute", left: CX - 300, top: PY - 300 + (1 - rise) * 360, width: 600, height: 600, borderRadius: "50%",
        background: `radial-gradient(circle, ${theme.colors.primary}, ${theme.colors.primary}00 68%)`, opacity: 0.85 * rise, filter: "blur(6px)" }} />
      {Array.from({ length: 22 }).map((_, i) => (
        <div key={i} style={{ position: "absolute", left: random(`mx${i}`) * 1080, top: 120 + ((random(`my${i}`) * 1000 - frame * (0.5 + random(`mv${i}`))) % 1000 + 1000) % 1000,
          width: 6, height: 6, borderRadius: "50%", background: theme.colors.accent, opacity: 0.18 + random(`mo${i}`) * 0.25 }} />
      ))}
      <div style={{ position: "absolute", left: CX - 260 + x, top: PY - 150 + Math.sin(frame / 20) * 16 }}>
        <Entrance delay={8}><Bird scale={1} /></Entrance>
      </div>
    </SceneWrap>
  );
};
