import React from "react";
import { AbsoluteFill, Audio, interpolate, Sequence, staticFile, useCurrentFrame } from "remotion";
import { Captions } from "./Captions";
import { BgMesh, Grade, Grain, Vignette } from "./Layers";
import { BirdScene, EraScene, ImpactScene, WinterScene } from "./Scenes";
import { ms2f, SCENES, theme } from "./theme";

// Drop the ElevenLabs voice-over at public/voice.mp3 and flip this to true.
const HAS_VO = false;

const seq = (r: readonly [number, number]) => ({ from: ms2f(r[0]), durationInFrames: ms2f(r[1]) - ms2f(r[0]) });

export const Dino: React.FC = () => {
  const impactF = ms2f(22980);
  const heat = (f: number) => interpolate(f, [impactF - 60, impactF + 20, ms2f(SCENES.winter[0])], [0, 1, 0.3], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <HeatBg heat={heat} />
      <Sequence {...seq(SCENES.era)}><EraScene /></Sequence>
      <Sequence {...seq(SCENES.impact)}><ImpactScene /></Sequence>
      <Sequence {...seq(SCENES.winter)}><WinterScene /></Sequence>
      <Sequence {...seq(SCENES.birds)}><BirdScene /></Sequence>
      <Captions />
      <Grade />
      <Grain />
      <Vignette />
      {HAS_VO && <Audio src={staticFile("voice.mp3")} />}
    </AbsoluteFill>
  );
};

const HeatBg: React.FC<{ heat: (f: number) => number }> = ({ heat }) => <BgMesh heat={heat(useCurrentFrame())} />;
