import React from "react";
import { AbsoluteFill, interpolate, Sequence, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { cues, Cue } from "./captions";
import { fontFamily } from "./fonts";
import { ms2f, theme } from "./theme";

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

// Words are split on spaces only — never per-character — so Bengali conjuncts keep their shaping.
const CueView: React.FC<{ cue: Cue }> = ({ cue }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const exit = interpolate(frame, [durationInFrames - 6, durationInFrames - 1], [1, 0], { easing: theme.ease.in, ...clamp });
  let wi = 0;
  return (
    <AbsoluteFill style={{ top: 1190, height: 380, justifyContent: "flex-start", alignItems: "center", opacity: exit,
      transform: `translateY(${interpolate(exit, [0, 1], [-14, 0])}px)` }}>
      <div style={{ width: 940, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
        {cue.lines.map((line, li) => (
          <div key={li} style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", columnGap: 20 }}>
            {line.split(" ").map((w, i) => {
              const p = spring({ frame: frame - wi++ * 3, fps, config: theme.spring.snappy });
              return (
                <span key={i} style={{ display: "inline-block", fontFamily, fontWeight: 800, fontSize: 72, lineHeight: 1.45,
                  color: theme.colors.text, opacity: p, transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px) scale(${interpolate(p, [0, 1], [0.94, 1])})`,
                  textShadow: "0 4px 30px rgba(0,0,0,0.85), 0 0 3px rgba(0,0,0,0.9)" }}>{w}</span>
              );
            })}
          </div>
        ))}
      </div>
    </AbsoluteFill>
  );
};

export const Captions: React.FC = () => (
  <>
    {cues.map((c, i) => {
      const from = ms2f(c.startMs);
      return (
        <Sequence key={i} from={from} durationInFrames={Math.max(12, ms2f(c.endMs) - from + 4)} layout="none">
          <CueView cue={c} />
        </Sequence>
      );
    })}
  </>
);
