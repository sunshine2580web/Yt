import React from "react";
import { Composition } from "remotion";
import { Dino } from "./Dino";
import { FPS, H, TOTAL_FRAMES, W } from "./theme";

export const Root: React.FC = () => (
  <Composition id="Dino" component={Dino} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);
