import { loadFont } from "@remotion/google-fonts/NotoSansBengali";
// Bengali shaping needs a real Bengali font. Loaded at render time (needs internet once).
export const { fontFamily } = loadFont("normal", { weights: ["500", "700", "800"], subsets: ["bengali", "latin"] });
