// Single source of truth. No inline colors / easings / springs in components.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#0B0705",
    bgAlt: "#1A0F09",
    primary: "#FF6A2B", // HERO: impact orange — max one hero element per frame
    accent: "#F4E9DA", // warm cream: captions + secondary graphics
    text: "#F4E9DA",
    textDim: "#B8A898",
    dust: "#3A2A20",
    glow: "rgba(255, 106, 43, 0.45)",
  },
  fonts: { display: "Noto Sans Bengali", body: "Noto Sans Bengali" },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const ms2f = (ms: number) => Math.round((ms / 1000) * FPS);
// Scene boundaries (ms) derived from the caption story beats
export const SCENES = {
  era: [0, 12000],
  impact: [12000, 30340],
  winter: [30340, 51200],
  birds: [51200, 67000],
} as const;
export const TOTAL_FRAMES = ms2f(67000);
export const bn = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);
